package com.divyanshu.nearbybusiness.Model

class Geometry {

    var viewport:Viewport?=null
    var location:Location?=null
}