package com.divyanshu.nearbybusiness.Model

class Location {

    var lat:Double=0.0
    var lng:Double=0.0
}