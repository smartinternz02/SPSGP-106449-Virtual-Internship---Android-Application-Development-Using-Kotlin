package com.divyanshu.nearbybusiness.Model

class Viewport {

    var northeast:Northeast?=null
    var southwest:Southwest?=null
}